import time
import cv2
from cars import Motors, Connection, Direction, Camera


def move_straight_test():
    cv2.namedWindow("demo")
    connection = Connection()
    cam = Camera(connection=connection)
    motors = Motors(connection=connection)

    for i in range(15):
        connection.keep_stream_alive()
        motors.command(80, Direction.FORWARD)
        img = cam.get_frame()
        #cv2.imwrite(f"move_straight/{i}.jpg", img)
        time.sleep(0.2)


def turn_around_test(blurred=False):
    cv2.namedWindow("demo")
    connection = Connection()
    cam = Camera(connection=connection)
    motors = Motors(connection=connection)

    cam.flash_on()
    time.sleep(1)
    cam.flash_off()

    i = 0
    while True:
        connection.keep_stream_alive()
        motors.command(80, Direction.LEFT)
        i += 1
        time.sleep(0.2)
        if not blurred:
            time.sleep(1)
        img = cam.get_frame()
        cv2.imshow("demo", img)
        if blurred:
            cv2.imwrite(f"turn_around_blurred/{i}.jpg", img)
        else:
            cv2.imwrite(f"turn_around/{i}.jpg", img)
        keypress = cv2.pollKey() & 0xFF
        if keypress == ord('q'):
            break


if __name__ == "__main__":
    # move_straight_test()
    # turn_around_test(blurred=True)
    turn_around_test(blurred=False)
